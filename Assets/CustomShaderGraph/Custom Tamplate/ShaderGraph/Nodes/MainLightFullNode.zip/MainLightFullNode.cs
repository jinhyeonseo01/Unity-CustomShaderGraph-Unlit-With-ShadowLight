using System.Reflection;
using UnityEngine;

namespace UnityEditor.ShaderGraph
{
    [Title("Input", "Lighting", "Main Light Full")]
    class MainLightFullNode : CodeFunctionNode
    {
        public MainLightFullNode()
        {
            name = "Main Light Full";
            synonyms = new string[] { "sun" };
        }

        public override bool hasPreview { get { return false; } }

        protected override MethodInfo GetFunctionToConvert()
        {
            return GetType().GetMethod("MainLightFull", BindingFlags.Static | BindingFlags.NonPublic);
        }

        //public void GenerateNodeFunction(FunctionRegistry registry, GenerationMode generationMode)
        //{
        //    registry.RequiresIncludePath("Packages/com.unity.render-pipelines.core/ShaderLibrary/BSDF.hlsl");

        //    registry.ProvideFunction(GetFunctionName(), s =>
        //    {
        //        s.AppendLine("void {0}(out $precision3 Refracted, out $precision3 Intensity, $precision3 Incident, $precision3 Normal, $precision IORSource, $precision IORMedium)", GetFunctionName());
        //        using (s.BlockScope())
        //        {
        //            s.AppendLine("$precision internalIORSource = max(IORSource, 1.0);");
        //            s.AppendLine("$precision internalIORMedium = max(IORMedium, 1.0);");
        //            s.AppendLine("$precision eta = internalIORSource/internalIORMedium;");
        //            s.AppendLine("$precision cos0 = dot(Incident, Normal);");
        //            s.AppendLine("$precision k = 1.0 - eta*eta*(1.0 - cos0*cos0);");
        //            if (m_RefractMode == RefractMode.Safe)
        //            {
        //                s.AppendLine("Refracted = eta*Incident - (eta*cos0 + sqrt(max(k, 0.0)))*Normal;");
        //            }
        //            else
        //            {
        //                s.AppendLine("Refracted = k >= 0.0 ? eta*Incident - (eta*cos0 + sqrt(k))*Normal : reflect(Incident, Normal);");
        //            }
        //            s.AppendLine("Intensity = internalIORSource <= internalIORMedium ?");
        //            s.AppendLine("    saturate(F_Transm_Schlick(IorToFresnel0(internalIORMedium, internalIORSource), -cos0)) :");
        //            s.AppendLine("    (k >= 0.0 ? F_FresnelDielectric(internalIORMedium/internalIORSource, -cos0) : ");
        //            if (m_RefractMode == RefractMode.Safe)
        //            {
        //                s.Append("0.0);");
        //            }
        //            else
        //            {
        //                s.Append("1.0);");
        //            }
        //        }
        //    });
        //}


        //[Slot(0, Binding.None)]
        //DynamicDimensionVector In,
        //    [Slot(1, Binding.None, ShaderStageCapability.Fragment)] out DynamicDimensionVector Out

        //    [Slot(0, Binding.None, -1, -1, -1, -1)] DynamicDimensionVector In,
        //    [Slot(1, Binding.None, -1, 1, 0, 0)] Vector2 InMinMax,
        //    [Slot(2, Binding.None, 0, 1, 0, 0)] Vector2 OutMinMax,
        //    [Slot(3, Binding.None)] out DynamicDimensionVector Out)

        static string MainLightFull(
            [Slot(0, Binding.None)] Vector3 PositionWS,
            [Slot(1, Binding.None)] Vector3 PositionCS,
            [Slot(2, Binding.None)] out Vector3 Direction,
            [Slot(3, Binding.None)] out Vector4 Color,
            [Slot(4, Binding.None)] out float DistanceAttenuation,
            [Slot(5, Binding.None)] out float ShadowAttenuation)
        {
            Direction = Vector3.one;
            Color = Vector4.one;
            DistanceAttenuation = 1;
            ShadowAttenuation = 1;
            return
@"
{
    #if SHADERGRAPH_PREVIEW
    Direction = half3(-0.5, -0.5, 0);
    #else

positionWS
positionCS

$precision4 shadowCoord;
$precision4 shadowMask = $precision4(1, 1, 1, 1);


    #if defined(MAIN_LIGHT_CALCULATE_SHADOWS)
        shadowCoord = TransformWorldToShadowCoord(positionWS);
    #else
        shadowCoord = $precision4(0, 0, 0, 0);
    #endif


    #if defined(SHADOWS_SHADOWMASK) && defined(LIGHTMAP_ON)
    shadowMask = inputData.shadowMask; // Shadowmask was sampled from lightmap
    #elif !defined(LIGHTMAP_ON) && (defined(PROBE_VOLUMES_L1) || defined(PROBE_VOLUMES_L2))
    shadowMask = inputData.shadowMask; // Shadowmask (probe occlusion) was sampled from APV
    #elif !defined (LIGHTMAP_ON)
    shadowMask = unity_ProbesOcclusion; // Sample shadowmask (probe occlusion) from legacy probes
    #else
    shadowMask = half4(1, 1, 1, 1); // Fallback shadowmask, fully unoccluded
    #endif



$precision2 normalizedScreenSpaceUV = GetNormalizedScreenSpaceUV(positionCS);
$precision occlusion = half(1.0);


    AmbientOcclusionFactor aoFactor;
    #if defined(_SCREEN_SPACE_OCCLUSION) && !defined(_SURFACE_TYPE_TRANSPARENT)

    	$precision2 uv = UnityStereoTransformScreenSpaceTex(normalizedScreenSpaceUV);
        $precision ssao = saturate($precision(SAMPLE_TEXTURE2D_X(_ScreenSpaceOcclusionTexture, sampler_LinearClamp, uv).x) + (1.0 - _AmbientOcclusionParam.x));
        aoFactor.indirectAmbientOcclusion = ssao;
        aoFactor.directAmbientOcclusion = lerp($precision(1.0), ssao, _AmbientOcclusionParam.w);
    #else
        aoFactor.directAmbientOcclusion = $precision(1.0);
        aoFactor.indirectAmbientOcclusion = $precision(1.0);
    #endif

    #if defined(DEBUG_DISPLAY)
    switch(_DebugLightingMode)
    {
        case DEBUGLIGHTINGMODE_LIGHTING_WITHOUT_NORMAL_MAPS:
            aoFactor.directAmbientOcclusion = 0.5;
            aoFactor.indirectAmbientOcclusion = 0.5;
            break;

        case DEBUGLIGHTINGMODE_LIGHTING_WITH_NORMAL_MAPS:
            aoFactor.directAmbientOcclusion *= 0.5;
            aoFactor.indirectAmbientOcclusion *= 0.5;
            break;
    }
    #endif

aoFactor.indirectAmbientOcclusion = min(aoFactor.indirectAmbientOcclusion, occlusion);


        Light light = GetMainLight();
        light.shadowAttenuation = MainLightShadow(shadowCoord, positionWS, shadowMask, _MainLightOcclusionProbes);

        #if defined(_LIGHT_COOKIES)
            $precision3 cookieColor = SampleMainLightCookie(positionWS);
            light.color *= cookieColor;
        #endif

        #if defined(_SCREEN_SPACE_OCCLUSION) && !defined(_SURFACE_TYPE_TRANSPARENT)
        if (IsLightingFeatureEnabled(DEBUGLIGHTINGFEATUREFLAGS_AMBIENT_OCCLUSION))
        {
            light.color *= aoFactor.directAmbientOcclusion;
        }
        #endif


        Direction = light.direction;
        DistanceAttenuation = light.distanceAttenuation
        ShadowAttenuation = light.shadowAttenuation
        Color = light.color
    #endif
}
";
        }
    }
}
